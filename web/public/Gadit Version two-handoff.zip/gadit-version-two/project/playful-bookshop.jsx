/* Direction 3 — PLAYFUL BOOKSHOP
   Apple Books meets the kids' aisle. Saturated, rounded, hard shadows. */

const playTokens = {
  butter:  '#FFF4D6',
  cream:   '#FFFAEC',
  plum:    '#2E1A47',
  plumSoft:'#5A3E7E',
  tomato:  '#FF6B47',
  tomatoSoft:'#FFB59F',
  mint:    '#34D399',
  mintSoft:'#A8EBCD',
  lilac:   '#A78BFA',
  lilacSoft:'#D6C8FB',
  sun:     '#FFC93C',
  sky:     '#7DD3FC',
  display: '"Bricolage Grotesque", "Rubik", system-ui, sans-serif',
  body:    'Nunito, "Heebo", system-ui, sans-serif',
  he:      '"Rubik", "Heebo", "Bricolage Grotesque", system-ui, sans-serif',
  hand:    '"Caveat", cursive',
};

const PL_CONTENT = {
  word: 'חלום',
  translit: 'ḥalom',
  ipa: '/xaˈlom/',
  definitions: [
    {
      tag: 'when you sleep',
      color: '#FF6B47',
      bg: '#FFE4D6',
      gloss: 'A sequence of pictures, ideas, and feelings that happen in your head while you sleep — sometimes wild, sometimes calm, sometimes very, very weird.',
      hebrew: 'ראיתי חלום מוזר אמש.',
      english: 'I had a strange dream last night.',
      sticker: 'moon',
    },
    {
      tag: 'when you hope',
      color: '#A78BFA',
      bg: '#EFE7FE',
      gloss: 'A big wish for something you really, really want to happen one day — the kind of thing you tell a best friend or a grandparent.',
      hebrew: 'החלום של אבא היה לבנות בית קטן ליד הים.',
      english: 'My dad’s dream was to build a tiny house by the sea.',
      sticker: 'star',
    },
  ],
  etymology: 'A very old Hebrew root, ḥ-l-m, that also lives in Arabic and Akkadian. Long ago, in the same family of words, it meant both “to dream” and “to be whole.” People used to say a good dream made you stronger.',
  tiles: [
    { num: '01', he: 'הסבר לילדים',  en: 'For kids',          desc: 'A picture-book version, with stories.',   tier: 'CLEAR', bg: '#FF6B47', shadow: '#2E1A47', face: 'smile' },
    { num: '02', he: 'חיבור משפט',    en: 'Make a sentence',    desc: 'Write your own. We’ll cheer you on.',     tier: 'CLEAR', bg: '#34D399', shadow: '#2E1A47', face: 'note' },
    { num: '03', he: 'השוואת מילים',  en: 'Compare words',      desc: 'חלום vs. הזיה vs. משאלה — friendly fight.', tier: 'DEEP',  bg: '#A78BFA', shadow: '#2E1A47', face: 'twin' },
    { num: '04', he: 'מבחן עצמי',     en: 'Pop quiz',           desc: 'Eight questions. No grades. Promise.',    tier: 'DEEP',  bg: '#FFC93C', shadow: '#2E1A47', face: 'quiz' },
  ],
};

/* ───── pseudo-illustrated stickers ───── */
function PLSticker({ kind, size = 56, hueA, hueB }) {
  const wrap = { width: size, height: size, position: 'relative', flexShrink: 0 };
  switch (kind) {
    case 'moon':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: hueA || playTokens.sun }} />
          <div style={{ position: 'absolute', inset: size * 0.08, top: size * 0.02, borderRadius: '50%', background: hueB || playTokens.butter, transform: `translate(${size * 0.18}px,${-size * 0.08}px)` }} />
          <div style={{ position: 'absolute', left: size * 0.18, top: size * 0.42, width: size * 0.07, height: size * 0.07, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.32, top: size * 0.42, width: size * 0.07, height: size * 0.07, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.2, top: size * 0.56, width: size * 0.22, height: size * 0.04, borderRadius: size, background: playTokens.plum }} />
        </div>
      );
    case 'star':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', inset: 0, borderRadius: 18, background: hueA || playTokens.lilac, transform: 'rotate(8deg)' }} />
          <div style={{ position: 'absolute', inset: size * 0.18, borderRadius: '50%', background: hueB || playTokens.cream }} />
          <div style={{ position: 'absolute', left: size * 0.3, top: size * 0.34, width: size * 0.08, height: size * 0.08, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.6, top: size * 0.34, width: size * 0.08, height: size * 0.08, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.38, top: size * 0.56, width: size * 0.2, height: size * 0.08, borderRadius: size, background: playTokens.plum }} />
        </div>
      );
    case 'smile':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: hueA || playTokens.cream }} />
          <div style={{ position: 'absolute', left: size * 0.24, top: size * 0.34, width: size * 0.12, height: size * 0.12, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.62, top: size * 0.34, width: size * 0.12, height: size * 0.12, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.28, top: size * 0.6, width: size * 0.42, height: size * 0.16, borderRadius: '0 0 99px 99px', background: playTokens.plum }} />
          <div style={{ position: 'absolute', left: size * 0.06, top: size * 0.46, width: size * 0.12, height: size * 0.08, borderRadius: '50%', background: '#FF8FA3', opacity: 0.7 }} />
          <div style={{ position: 'absolute', left: size * 0.8, top: size * 0.46, width: size * 0.12, height: size * 0.08, borderRadius: '50%', background: '#FF8FA3', opacity: 0.7 }} />
        </div>
      );
    case 'note':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', inset: size * 0.06, borderRadius: 10, background: hueA || playTokens.cream, transform: 'rotate(-4deg)' }} />
          <div style={{ position: 'absolute', left: size * 0.2, top: size * 0.3, width: size * 0.6, height: size * 0.08, borderRadius: size, background: playTokens.plum, transform: 'rotate(-4deg)' }} />
          <div style={{ position: 'absolute', left: size * 0.2, top: size * 0.46, width: size * 0.5, height: size * 0.08, borderRadius: size, background: playTokens.plum, transform: 'rotate(-4deg)', opacity: 0.7 }} />
          <div style={{ position: 'absolute', left: size * 0.2, top: size * 0.62, width: size * 0.35, height: size * 0.08, borderRadius: size, background: playTokens.plum, transform: 'rotate(-4deg)', opacity: 0.5 }} />
        </div>
      );
    case 'twin':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', left: 0, top: size * 0.18, width: size * 0.62, height: size * 0.7, borderRadius: 16, background: playTokens.tomato, transform: 'rotate(-6deg)' }} />
          <div style={{ position: 'absolute', right: 0, top: size * 0.1, width: size * 0.62, height: size * 0.7, borderRadius: 16, background: playTokens.mint, transform: 'rotate(8deg)' }} />
          <div style={{ position: 'absolute', left: size * 0.16, top: size * 0.42, width: size * 0.1, height: size * 0.1, borderRadius: '50%', background: playTokens.plum }} />
          <div style={{ position: 'absolute', right: size * 0.16, top: size * 0.42, width: size * 0.1, height: size * 0.1, borderRadius: '50%', background: playTokens.plum }} />
        </div>
      );
    case 'quiz':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: hueA || playTokens.tomato }} />
          <div style={{
            position: 'absolute',
            inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: playTokens.display, fontWeight: 800,
            fontSize: size * 0.6,
            color: playTokens.cream,
            lineHeight: 1,
            transform: 'rotate(-8deg)',
          }}>?</div>
        </div>
      );
    case 'cloud':
      return (
        <div style={wrap}>
          <div style={{ position: 'absolute', left: 0, top: size * 0.35, width: size * 0.4, height: size * 0.4, borderRadius: '50%', background: playTokens.cream }} />
          <div style={{ position: 'absolute', left: size * 0.25, top: size * 0.2, width: size * 0.45, height: size * 0.45, borderRadius: '50%', background: playTokens.cream }} />
          <div style={{ position: 'absolute', right: 0, top: size * 0.35, width: size * 0.4, height: size * 0.4, borderRadius: '50%', background: playTokens.cream }} />
        </div>
      );
    default:
      return null;
  }
}

/* ───── floating decorations ───── */
function PLDecor({ count = 3, palette = ['#FFC93C', '#FF6B47', '#34D399', '#A78BFA', '#7DD3FC'], wide }) {
  const positions = wide
    ? [
        { left: '6%',  top: 80,  size: 16, hue: 0, rot: -10 },
        { right: '8%', top: 60,  size: 22, hue: 2, rot: 14 },
        { left: '18%', top: 220, size: 10, hue: 1, rot: 0 },
        { right: '22%',top: 240, size: 14, hue: 4, rot: -8 },
        { right: '4%', top: 380, size: 18, hue: 3, rot: 20 },
        { left: '4%',  top: 420, size: 12, hue: 1, rot: 6 },
      ]
    : [
        { right: '6%', top: 40, size: 12, hue: 0, rot: 0 },
        { left: '5%',  top: 90, size: 10, hue: 2, rot: 10 },
        { right: '12%',top: 160,size: 14, hue: 4, rot: -10 },
      ];
  return positions.slice(0, count).map((p, i) => (
    <div key={i} style={{
      position: 'absolute',
      left: p.left, right: p.right, top: p.top,
      width: p.size, height: p.size,
      borderRadius: '50%',
      background: palette[p.hue % palette.length],
      transform: `rotate(${p.rot}deg)`,
      boxShadow: `2px 2px 0 ${playTokens.plum}`,
    }} />
  ));
}

/* ───── nav ───── */
function PLNav({ wide }) {
  return (
    <div style={{
      direction: 'rtl',
      padding: wide ? '20px 48px' : '14px 16px',
      display: 'flex',
      alignItems: 'center',
      gap: wide ? 20 : 10,
      fontFamily: playTokens.body,
      fontWeight: 700,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, direction: 'ltr' }}>
        <div style={{
          width: 40, height: 40, borderRadius: 14, background: playTokens.tomato,
          boxShadow: `3px 3px 0 ${playTokens.plum}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: playTokens.display, fontWeight: 800, fontSize: 22, color: playTokens.cream,
          transform: 'rotate(-4deg)',
        }}>G</div>
        <span style={{ fontFamily: playTokens.display, fontWeight: 800, fontSize: 24, color: playTokens.plum, letterSpacing: '-0.02em' }}>Gadit</span>
      </div>
      {wide && (
        <>
          <div style={{ marginInlineStart: 16, padding: '8px 16px', borderRadius: 99, background: playTokens.cream, border: `2px solid ${playTokens.plum}`, boxShadow: `3px 3px 0 ${playTokens.plum}`, display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, color: playTokens.plum }}>
            <span style={{ fontFamily: playTokens.he, fontWeight: 700 }}>חיפוש מילה...</span>
            <span style={{ opacity: 0.5, fontSize: 12 }}>· Search</span>
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 14px', borderRadius: 99, color: playTokens.plum, fontSize: 14 }}>
            <span style={{ fontFamily: playTokens.he, fontWeight: 700 }}>תמחור</span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>Pricing</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 14px', borderRadius: 99, background: playTokens.lilacSoft, color: playTokens.plum, fontSize: 13 }}>
            🌐 HE / EN
          </div>
          <button style={{
            background: playTokens.plum, color: playTokens.butter,
            border: 'none', padding: '10px 22px', borderRadius: 99,
            fontFamily: playTokens.body, fontWeight: 800, fontSize: 14,
            boxShadow: `3px 3px 0 ${playTokens.tomato}`,
            cursor: 'pointer',
          }}>Sign in →</button>
        </>
      )}
      {!wide && (
        <div style={{ marginInlineStart: 'auto', display: 'flex', gap: 8 }}>
          <div style={{ width: 36, height: 36, borderRadius: 12, background: playTokens.cream, border: `2px solid ${playTokens.plum}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, color: playTokens.plum }}>🔍</div>
          <button style={{ background: playTokens.plum, color: playTokens.butter, border: 'none', padding: '8px 14px', borderRadius: 99, fontWeight: 800, fontSize: 12, boxShadow: `3px 3px 0 ${playTokens.tomato}` }}>Sign in</button>
        </div>
      )}
    </div>
  );
}

/* ───── word head ───── */
function PLWordHead({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '36px 48px 24px' : '20px 16px 12px', position: 'relative' }}>
      {wide && <PLDecor wide count={6} />}
      {!wide && <PLDecor wide={false} count={3} />}
      <div style={{ position: 'relative', display: 'flex', alignItems: wide ? 'center' : 'flex-start', justifyContent: 'space-between', gap: wide ? 24 : 12, flexDirection: wide ? 'row' : 'column' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: playTokens.hand, fontSize: wide ? 32 : 24, color: playTokens.tomato, transform: 'rotate(-4deg)', display: 'inline-block', marginBottom: -8 }}>
            today’s word ✨
          </div>
          <div style={{
            fontFamily: playTokens.he,
            fontWeight: 900,
            fontSize: wide ? 220 : 120,
            lineHeight: 1,
            color: playTokens.plum,
            letterSpacing: '-0.03em',
            textShadow: `6px 6px 0 ${playTokens.tomato}`,
            position: 'relative',
            display: 'inline-block',
          }}>
            {PL_CONTENT.word}
          </div>
          <div style={{ marginTop: wide ? 16 : 12, display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{
              fontFamily: playTokens.display,
              fontWeight: 700,
              fontSize: wide ? 28 : 22,
              color: playTokens.plum,
              background: playTokens.sun,
              padding: '4px 14px',
              borderRadius: 99,
              boxShadow: `3px 3px 0 ${playTokens.plum}`,
              transform: 'rotate(-2deg)',
              display: 'inline-block',
            }}>ḥalom</span>
            <span style={{ fontFamily: playTokens.body, fontWeight: 700, fontSize: wide ? 18 : 14, color: playTokens.plumSoft }}>/xaˈlom/</span>
            <span style={{ fontFamily: playTokens.body, fontWeight: 800, fontSize: wide ? 14 : 12, color: playTokens.plum, padding: '4px 12px', borderRadius: 99, background: playTokens.mintSoft }}>
              noun · masculine
            </span>
            <span style={{ fontFamily: playTokens.body, fontWeight: 800, fontSize: wide ? 14 : 12, color: playTokens.plum, padding: '4px 12px', borderRadius: 99, background: playTokens.lilacSoft, direction: 'rtl' }}>
              ר״ב <span style={{ fontFamily: playTokens.he, fontWeight: 900 }}>חלומות</span>
            </span>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'stretch' }}>
          <button style={{
            display: 'inline-flex', alignItems: 'center', gap: 10,
            background: playTokens.tomato, color: playTokens.cream,
            border: `3px solid ${playTokens.plum}`, padding: wide ? '12px 22px' : '10px 16px',
            borderRadius: 99, fontFamily: playTokens.body, fontWeight: 800, fontSize: wide ? 16 : 14,
            boxShadow: `4px 4px 0 ${playTokens.plum}`,
            cursor: 'pointer', justifyContent: 'center',
          }}>
            <span style={{ fontSize: wide ? 22 : 18 }}>★</span>
            Save to my shelf
          </button>
          <button style={{
            display: 'inline-flex', alignItems: 'center', gap: 10,
            background: playTokens.cream, color: playTokens.plum,
            border: `3px solid ${playTokens.plum}`, padding: wide ? '12px 22px' : '10px 16px',
            borderRadius: 99, fontFamily: playTokens.body, fontWeight: 800, fontSize: wide ? 16 : 14,
            boxShadow: `4px 4px 0 ${playTokens.plum}`,
            cursor: 'pointer', justifyContent: 'center',
          }}>
            <span style={{ fontSize: wide ? 22 : 18 }}>↗</span>
            Share
          </button>
        </div>
      </div>
    </div>
  );
}

/* ───── section header ───── */
function PLSecHead({ num, en, he, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
      <span style={{
        fontFamily: playTokens.display, fontWeight: 800,
        fontSize: 16, color: playTokens.cream,
        background: color,
        padding: '4px 12px', borderRadius: 99,
        boxShadow: `2px 2px 0 ${playTokens.plum}`,
      }}>{num}</span>
      <span style={{ fontFamily: playTokens.display, fontWeight: 800, fontSize: 28, color: playTokens.plum }}>{en}</span>
      <span style={{ fontFamily: playTokens.he, fontWeight: 700, fontSize: 22, color: playTokens.plumSoft }}>· {he}</span>
    </div>
  );
}

/* ───── definitions ───── */
function PLDefinitions({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '24px 48px 0' : '20px 16px 0' }}>
      <PLSecHead num="01" en="What it means" he="הגדרות" color={playTokens.tomato} />
      <div style={{ marginTop: wide ? 24 : 18, display: 'grid', gridTemplateColumns: wide ? '1fr 1fr' : '1fr', gap: wide ? 24 : 16 }}>
        {PL_CONTENT.definitions.map((d, i) => (
          <div key={i} style={{
            background: d.bg,
            border: `3px solid ${playTokens.plum}`,
            borderRadius: 28,
            padding: wide ? '24px 24px 22px' : '18px 18px 16px',
            position: 'relative',
            boxShadow: `6px 6px 0 ${playTokens.plum}`,
            transform: i === 0 ? 'rotate(-0.6deg)' : 'rotate(0.6deg)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <PLSticker kind={d.sticker} size={wide ? 64 : 52} hueA={d.color} />
              <div>
                <div style={{ fontFamily: playTokens.hand, fontSize: wide ? 26 : 22, color: playTokens.plum, lineHeight: 1 }}>{d.tag}</div>
                <div style={{ fontFamily: playTokens.display, fontWeight: 800, fontSize: wide ? 16 : 13, color: playTokens.plumSoft, letterSpacing: '0.04em', textTransform: 'uppercase', marginTop: 2 }}>sense {i + 1} of 2</div>
              </div>
            </div>
            <p style={{
              margin: wide ? '18px 0 0' : '14px 0 0',
              fontFamily: playTokens.body, fontWeight: 600,
              fontSize: wide ? 18 : 16, lineHeight: 1.55, color: playTokens.plum, textWrap: 'pretty',
            }}>{d.gloss}</p>
            <div style={{
              marginTop: wide ? 18 : 14,
              padding: wide ? '14px 16px' : '12px 14px',
              background: playTokens.cream,
              border: `2px dashed ${playTokens.plum}`,
              borderRadius: 18,
            }}>
              <div style={{ fontFamily: playTokens.he, fontWeight: 700, fontSize: wide ? 22 : 18, color: playTokens.plum, lineHeight: 1.4 }}>{d.hebrew}</div>
              <div style={{ fontFamily: playTokens.hand, fontSize: wide ? 22 : 18, color: d.color, marginTop: 4, direction: 'ltr', textAlign: 'right', lineHeight: 1.1 }}>“{d.english}”</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ───── etymology ───── */
function PLEtymology({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '48px 48px 0' : '32px 16px 0' }}>
      <PLSecHead num="02" en="Where it comes from" he="מקור המילה" color={playTokens.lilac} />
      <div style={{
        marginTop: wide ? 24 : 18,
        background: playTokens.lilacSoft,
        border: `3px solid ${playTokens.plum}`,
        borderRadius: 32,
        padding: wide ? '32px 36px' : '20px',
        position: 'relative',
        boxShadow: `6px 6px 0 ${playTokens.plum}`,
        display: 'grid',
        gridTemplateColumns: wide ? '260px 1fr' : '1fr',
        gap: wide ? 36 : 18,
        alignItems: 'center',
      }}>
        <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
          <div style={{
            width: wide ? 200 : 160, height: wide ? 200 : 160, borderRadius: '50%',
            background: playTokens.sun,
            border: `3px solid ${playTokens.plum}`,
            boxShadow: `4px 4px 0 ${playTokens.plum}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: playTokens.he, fontWeight: 900,
            fontSize: wide ? 64 : 50,
            color: playTokens.plum, letterSpacing: '0.18em',
            transform: 'rotate(-6deg)',
          }}>
            ח · ל · מ
          </div>
          <div style={{ fontFamily: playTokens.hand, fontSize: wide ? 26 : 22, color: playTokens.plum, transform: 'rotate(2deg)' }}>
            the family root!
          </div>
        </div>
        <div>
          <p style={{
            margin: 0,
            fontFamily: playTokens.body, fontWeight: 600,
            fontSize: wide ? 19 : 16, lineHeight: 1.6, color: playTokens.plum, textWrap: 'pretty',
          }}>{PL_CONTENT.etymology}</p>
          <div style={{ marginTop: wide ? 18 : 14, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[
              { lang: 'Arabic',   form: 'ḥulm' },
              { lang: 'Akkadian', form: 'ḫalāmu' },
              { lang: 'Ge‘ez',    form: 'ḥalama' },
            ].map((c) => (
              <span key={c.lang} style={{
                fontFamily: playTokens.body, fontWeight: 800, fontSize: wide ? 13 : 12,
                background: playTokens.cream,
                color: playTokens.plum,
                border: `2px solid ${playTokens.plum}`,
                borderRadius: 99,
                padding: '5px 12px',
                boxShadow: `2px 2px 0 ${playTokens.plum}`,
              }}>
                <span style={{ opacity: 0.6 }}>{c.lang} ·</span> {c.form}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───── visual ───── */
function PLVisual({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '48px 48px 0' : '32px 16px 0' }}>
      <PLSecHead num="03" en="Picture it" he="מחשה" color={playTokens.mint} />
      <div style={{
        marginTop: wide ? 24 : 18,
        background: playTokens.mintSoft,
        border: `3px solid ${playTokens.plum}`,
        borderRadius: 28,
        height: wide ? 360 : 220,
        position: 'relative',
        overflow: 'hidden',
        boxShadow: `6px 6px 0 ${playTokens.plum}`,
      }}>
        {/* Sky scene */}
        <div style={{ position: 'absolute', left: '8%',  top: '20%', }}><PLSticker kind="cloud" size={wide ? 110 : 70} /></div>
        <div style={{ position: 'absolute', right: '12%', top: '12%' }}><PLSticker kind="moon" size={wide ? 90 : 60} /></div>
        <div style={{ position: 'absolute', right: '40%', top: '50%' }}><PLSticker kind="cloud" size={wide ? 80 : 50} /></div>
        <div style={{ position: 'absolute', left: '30%', top: '60%' }}><PLSticker kind="star" size={wide ? 70 : 46} /></div>
        <div style={{
          position: 'absolute', left: '50%', bottom: 14, transform: 'translateX(-50%)',
          fontFamily: playTokens.hand, fontSize: wide ? 30 : 22,
          color: playTokens.plum,
          background: playTokens.cream,
          padding: '6px 16px', borderRadius: 99,
          border: `2px solid ${playTokens.plum}`,
          boxShadow: `3px 3px 0 ${playTokens.plum}`,
          direction: 'ltr',
        }}>
          a dream — soft, weird, full of clouds
        </div>
      </div>
    </section>
  );
}

/* ───── tier badge ───── */
function PLTier({ tier }) {
  const isDeep = tier === 'DEEP';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      fontFamily: playTokens.body, fontWeight: 800, fontSize: 11,
      padding: '3px 10px',
      borderRadius: 99,
      background: playTokens.cream,
      color: playTokens.plum,
      border: `2px solid ${playTokens.plum}`,
      boxShadow: `2px 2px 0 ${playTokens.plum}`,
      letterSpacing: '0.04em',
    }}>
      {isDeep ? '🔒 DEEP' : '✨ CLEAR'}
    </span>
  );
}

/* ───── tiles ───── */
function PLTiles({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '48px 48px 0' : '32px 16px 0' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
        <PLSecHead num="04" en="Take it further" he="להעמיק" color={playTokens.sun} />
        <span style={{ fontFamily: playTokens.hand, fontSize: wide ? 24 : 20, color: playTokens.plumSoft, transform: 'rotate(-2deg)' }}>pick a room →</span>
      </div>
      <div style={{
        marginTop: wide ? 24 : 18,
        display: 'grid',
        gridTemplateColumns: wide ? 'repeat(4, 1fr)' : '1fr',
        gap: wide ? 20 : 14,
      }}>
        {PL_CONTENT.tiles.map((t, i) => (
          <div key={i} style={{
            background: t.bg,
            border: `3px solid ${playTokens.plum}`,
            borderRadius: 28,
            padding: wide ? '20px 20px 22px' : '18px 18px 20px',
            boxShadow: `6px 6px 0 ${t.shadow}`,
            transform: i % 2 ? 'rotate(0.8deg)' : 'rotate(-0.8deg)',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column',
            gap: 14,
            minHeight: wide ? 220 : 170,
            color: playTokens.plum,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <PLSticker kind={t.face} size={wide ? 64 : 56} hueA={playTokens.cream} />
              <PLTier tier={t.tier} />
            </div>
            <div>
              <div style={{ fontFamily: playTokens.he, fontWeight: 900, fontSize: wide ? 24 : 20, lineHeight: 1.1 }}>{t.he}</div>
              <div style={{ fontFamily: playTokens.display, fontWeight: 700, fontSize: wide ? 15 : 13, color: playTokens.plumSoft, marginTop: 2 }}>{t.en}</div>
              <div style={{ fontFamily: playTokens.body, fontWeight: 600, fontSize: wide ? 14 : 13, marginTop: 8, lineHeight: 1.45 }}>{t.desc}</div>
            </div>
            <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: playTokens.body, fontWeight: 800, fontSize: 11, opacity: 0.6 }}>{t.num} / 04</span>
              <span style={{
                fontFamily: playTokens.body, fontWeight: 800, fontSize: 13,
                display: 'inline-flex', alignItems: 'center', gap: 4,
                background: playTokens.cream,
                padding: '5px 12px', borderRadius: 99,
                border: `2px solid ${playTokens.plum}`,
              }}>Open →</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ───── footer ───── */
function PLFooter({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '56px 48px 40px' : '32px 16px 24px', textAlign: 'center', fontFamily: playTokens.hand, fontSize: wide ? 28 : 22, color: playTokens.plumSoft }}>
      made with crayons &amp; commas — Gadit ✦
    </div>
  );
}

/* ───── full pages ───── */
function DesktopPlayfulBookshop() {
  return (
    <div style={{ width: 1440, minHeight: 2520, background: playTokens.butter, color: playTokens.plum, fontFamily: playTokens.body, position: 'relative', overflow: 'hidden' }}>
      <PLNav wide />
      <PLWordHead wide />
      <PLDefinitions wide />
      <PLEtymology wide />
      <PLVisual wide />
      <PLTiles wide />
      <PLFooter wide />
    </div>
  );
}
function MobilePlayfulBookshop() {
  return (
    <div style={{ width: 390, minHeight: 2280, background: playTokens.butter, color: playTokens.plum, fontFamily: playTokens.body, position: 'relative', overflow: 'hidden' }}>
      <PLNav wide={false} />
      <PLWordHead wide={false} />
      <PLDefinitions wide={false} />
      <PLEtymology wide={false} />
      <PLVisual wide={false} />
      <PLTiles wide={false} />
      <PLFooter wide={false} />
    </div>
  );
}

Object.assign(window, { DesktopPlayfulBookshop, MobilePlayfulBookshop });
