/* Direction 1 — WARM LIBRARY
   A printed reference book. Serif everywhere, hairline rules, no cards. */

const warmTokens = {
  cream:  '#F2EAD6',
  paper:  '#EAE0C7',
  ink:    '#1F1A12',
  pencil: '#6B6358',
  faint:  '#C9BC9C',
  rule:   '#3A3328',
  oxblood:'#8B2A1A',
  forest: '#3A5A3A',
  hebrewSerif: '"Frank Ruhl Libre", "EB Garamond", serif',
  bodySerif:   '"EB Garamond", "Frank Ruhl Libre", serif',
  display:     '"Cormorant Garamond", "Frank Ruhl Libre", serif',
  smallcaps:   '"Cormorant SC", "EB Garamond", serif',
};

/* Shared text content */
const WL_CONTENT = {
  word: 'חלום',
  translit: 'ḥalom',
  ipa: '/xaˈlom/',
  partOfSpeech: 'noun · masculine',
  plural: 'חלומות',
  definitions: [
    {
      n: 'I.',
      gloss: 'A sequence of images, ideas, and sensations occurring involuntarily in the mind during sleep; the experience of dreaming.',
      hebrew: 'ראיתי חלום מוזר אמש.',
      english: '“I had a strange dream last night.”',
    },
    {
      n: 'II.',
      gloss: 'A cherished aspiration; an ideal that one hopes to attain — often used with possessive (החלום שלי, ‘my dream’).',
      hebrew: 'החלום של אבא היה לבנות בית קטן ליד הים.',
      english: '“Father’s dream was to build a small house by the sea.”',
    },
  ],
  etymology: 'From the Proto-Semitic root ḥ-l-m, denoting both ‘to dream’ and, in some cognates, ‘to be whole, to be sound’. Cognate with Akkadian ḫalāmu, Arabic ḥulm (حُلم), and Ge‘ez ḥalama. In Biblical Hebrew the word carries prophetic weight — the Joseph cycle of Genesis 37 anchors it as the medium through which the divine speaks to a sleeping mind.',
  tiles: [
    { num: 'i.',   he: 'הסבר לילדים',     en: 'Explanation for children',    desc: 'A simple retelling with everyday examples a seven-year-old would follow.', tier: 'CLEAR' },
    { num: 'ii.',  he: 'חיבור משפט',       en: 'Compose a sentence',          desc: 'Practice using חלום in your own writing, with feedback on register.', tier: 'CLEAR' },
    { num: 'iii.', he: 'השוואת מילים',     en: 'Compare related words',       desc: 'חלום vs. הזיה vs. משאלה — when each one belongs.', tier: 'DEEP' },
    { num: 'iv.',  he: 'מבחן עצמי',        en: 'Quiz yourself',               desc: 'Eight questions that move from recall to fine distinction.', tier: 'DEEP' },
  ],
};

/* ───── small parts ───── */
const WLRule = ({ color = warmTokens.rule, thickness = 1, style = {} }) => (
  <div style={{ height: thickness, background: color, ...style }} />
);
const WLDoubleRule = () => (
  <div>
    <div style={{ height: 2, background: warmTokens.rule }} />
    <div style={{ height: 4 }} />
    <div style={{ height: 1, background: warmTokens.rule }} />
  </div>
);
const WLOrnament = ({ size = 14, color = warmTokens.ink }) => (
  <span style={{ display: 'inline-block', fontFamily: warmTokens.display, fontSize: size, color, lineHeight: 1, letterSpacing: '0.4em' }}>❦</span>
);

const WLTier = ({ tier }) => (
  <span style={{
    fontFamily: warmTokens.smallcaps,
    fontSize: 10,
    letterSpacing: '0.22em',
    color: tier === 'DEEP' ? warmTokens.oxblood : warmTokens.pencil,
    borderBottom: `1px solid ${tier === 'DEEP' ? warmTokens.oxblood : warmTokens.pencil}`,
    paddingBottom: 1,
  }}>
    {tier === 'DEEP' ? '· DEEP ·' : '· CLEAR ·'}
  </span>
);

/* ───── nav ───── */
function WLNav({ wide }) {
  const items = [
    { he: 'חיפוש',  en: 'Search'   },
    { he: 'תמחור',  en: 'Pricing'  },
  ];
  return (
    <div style={{
      direction: 'rtl',
      padding: wide ? '22px 80px 0' : '18px 24px 0',
      color: warmTokens.ink,
      fontFamily: warmTokens.bodySerif,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div style={{
          fontFamily: warmTokens.display,
          fontStyle: 'italic',
          fontWeight: 500,
          fontSize: wide ? 28 : 24,
          letterSpacing: '0.02em',
          direction: 'ltr',
        }}>
          Gadit<span style={{ color: warmTokens.oxblood }}>.</span>
        </div>
        {wide && (
          <div style={{ display: 'flex', gap: 28, alignItems: 'baseline' }}>
            {items.map((it) => (
              <div key={it.en} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <span style={{ fontSize: 17 }}>{it.he}</span>
                <span style={{ fontFamily: warmTokens.smallcaps, fontSize: 9, letterSpacing: '0.22em', color: warmTokens.pencil, marginTop: 1 }}>{it.en}</span>
              </div>
            ))}
            <div style={{ width: 1, background: warmTokens.rule, alignSelf: 'stretch', margin: '0 6px' }} />
            <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', fontFamily: warmTokens.smallcaps, fontSize: 10, letterSpacing: '0.22em', color: warmTokens.pencil }}>
              <span style={{ color: warmTokens.ink }}>HE</span>
              <span>·</span>
              <span>EN</span>
              <span>·</span>
              <span>AR</span>
            </div>
            <div style={{ width: 1, background: warmTokens.rule, alignSelf: 'stretch', margin: '0 6px' }} />
            <div style={{ fontFamily: warmTokens.smallcaps, fontSize: 11, letterSpacing: '0.22em', color: warmTokens.ink, paddingBottom: 1, borderBottom: `1px solid ${warmTokens.ink}` }}>SIGN IN</div>
          </div>
        )}
        {!wide && (
          <div style={{ display: 'flex', gap: 14, alignItems: 'baseline', fontFamily: warmTokens.smallcaps, fontSize: 10, letterSpacing: '0.22em', color: warmTokens.pencil }}>
            <span>HE · EN</span>
            <span>·</span>
            <span style={{ color: warmTokens.ink }}>SIGN IN</span>
          </div>
        )}
      </div>
      <div style={{ marginTop: wide ? 18 : 14 }}><WLDoubleRule /></div>
    </div>
  );
}

/* ───── word head ───── */
function WLWordHead({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '56px 120px 32px' : '36px 24px 24px', textAlign: 'center', color: warmTokens.ink }}>
      <div style={{ fontFamily: warmTokens.smallcaps, fontSize: wide ? 12 : 11, letterSpacing: '0.32em', color: warmTokens.pencil }}>
        ENTRY ONE · ערך אחד
      </div>
      <div style={{ marginTop: wide ? 12 : 8, fontFamily: warmTokens.hebrewSerif, fontWeight: 500, fontSize: wide ? 184 : 96, lineHeight: 1, letterSpacing: '-0.01em' }}>
        {WL_CONTENT.word}
      </div>
      <div style={{ marginTop: wide ? 14 : 10, fontFamily: warmTokens.display, fontStyle: 'italic', fontSize: wide ? 30 : 22, color: warmTokens.pencil }}>
        ḥalom <span style={{ color: warmTokens.faint, margin: '0 8px' }}>·</span> <span style={{ fontFamily: warmTokens.bodySerif }}>/xaˈlom/</span>
      </div>
      <div style={{ marginTop: wide ? 18 : 14, display: 'flex', gap: wide ? 32 : 18, justifyContent: 'center', alignItems: 'baseline', fontFamily: warmTokens.smallcaps, fontSize: wide ? 12 : 10, letterSpacing: '0.22em', color: warmTokens.pencil }}>
        <span>noun · שם עצם</span>
        <span style={{ color: warmTokens.faint }}>·</span>
        <span>masculine · זכר</span>
        <span style={{ color: warmTokens.faint }}>·</span>
        <span>pl. <span style={{ fontFamily: warmTokens.hebrewSerif, fontStyle: 'normal', fontSize: wide ? 16 : 14 }}>חלומות</span></span>
      </div>
      <div style={{ marginTop: wide ? 28 : 20, display: 'flex', gap: wide ? 20 : 14, justifyContent: 'center' }}>
        <button style={{
          background: 'transparent',
          border: `1px solid ${warmTokens.ink}`,
          padding: wide ? '8px 18px 7px' : '7px 14px 6px',
          fontFamily: warmTokens.smallcaps,
          fontSize: wide ? 11 : 10,
          letterSpacing: '0.28em',
          color: warmTokens.ink,
          cursor: 'pointer',
        }}>+ SAVE TO SHELF</button>
        <button style={{
          background: 'transparent',
          border: 'none',
          padding: wide ? '8px 6px 7px' : '7px 4px 6px',
          fontFamily: warmTokens.smallcaps,
          fontSize: wide ? 11 : 10,
          letterSpacing: '0.28em',
          color: warmTokens.ink,
          cursor: 'pointer',
          borderBottom: `1px solid ${warmTokens.ink}`,
        }}>SHARE ENTRY</button>
      </div>
    </div>
  );
}

/* ───── section heading ───── */
function WLSectionHead({ roman, en, he, wide }) {
  return (
    <div style={{ direction: 'rtl', display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: wide ? 28 : 18 }}>
      <div style={{ fontFamily: warmTokens.display, fontSize: wide ? 26 : 20, fontStyle: 'italic', color: warmTokens.oxblood, minWidth: wide ? 56 : 36 }}>{roman}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: warmTokens.smallcaps, fontSize: wide ? 14 : 12, letterSpacing: '0.28em', color: warmTokens.ink }}>{en}</div>
        <div style={{ fontFamily: warmTokens.hebrewSerif, fontSize: wide ? 22 : 18, color: warmTokens.ink, marginTop: 2 }}>{he}</div>
      </div>
      <div style={{ flex: 4, height: 1, background: warmTokens.rule }} />
    </div>
  );
}

/* ───── definitions ───── */
function WLDefinitions({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '0 120px' : '0 24px' }}>
      <WLSectionHead roman="I." en="DEFINITIONS" he="הגדרות" wide={wide} />
      <div style={{ display: 'grid', gridTemplateColumns: wide ? '1fr 1px 1fr' : '1fr', gap: wide ? 56 : 32 }}>
        {WL_CONTENT.definitions.map((d, i) => (
          <React.Fragment key={i}>
            {i === 1 && wide && <div style={{ background: warmTokens.rule }} />}
            <div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
                <span style={{ fontFamily: warmTokens.display, fontSize: wide ? 56 : 40, fontStyle: 'italic', color: warmTokens.oxblood, lineHeight: 1 }}>{d.n}</span>
                <span style={{ fontFamily: warmTokens.smallcaps, fontSize: wide ? 11 : 10, letterSpacing: '0.28em', color: warmTokens.pencil }}>
                  {i === 0 ? 'SENSE — SLEEP' : 'SENSE — ASPIRATION'}
                </span>
              </div>
              <p style={{
                fontFamily: warmTokens.bodySerif,
                fontSize: wide ? 22 : 18,
                lineHeight: 1.55,
                color: warmTokens.ink,
                margin: wide ? '14px 0 0' : '12px 0 0',
                textWrap: 'pretty',
              }}>{d.gloss}</p>
              <div style={{ marginTop: wide ? 24 : 18, paddingRight: wide ? 18 : 12, borderRight: `2px solid ${warmTokens.oxblood}` }}>
                <div style={{ fontFamily: warmTokens.hebrewSerif, fontSize: wide ? 22 : 18, color: warmTokens.ink, lineHeight: 1.5 }}>
                  {d.hebrew}
                </div>
                <div style={{ fontFamily: warmTokens.bodySerif, fontStyle: 'italic', fontSize: wide ? 16 : 14, color: warmTokens.pencil, marginTop: 6, direction: 'ltr', textAlign: 'right' }}>
                  {d.english}
                </div>
              </div>
            </div>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

/* ───── etymology ───── */
function WLEtymology({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '0 120px' : '0 24px', marginTop: wide ? 72 : 48 }}>
      <WLSectionHead roman="II." en="ETYMOLOGY" he="מקור המילה" wide={wide} />
      <div style={{ display: 'grid', gridTemplateColumns: wide ? '180px 1fr' : '1fr', gap: wide ? 56 : 16, alignItems: 'start' }}>
        <div style={{ direction: 'ltr', fontFamily: warmTokens.smallcaps, fontSize: wide ? 11 : 10, letterSpacing: '0.22em', color: warmTokens.pencil, textAlign: wide ? 'left' : 'right' }}>
          <div>ROOT</div>
          <div style={{ fontFamily: warmTokens.hebrewSerif, fontSize: wide ? 32 : 24, color: warmTokens.ink, letterSpacing: '0.15em', marginTop: 6 }}>ח–ל–מ</div>
          <div style={{ marginTop: wide ? 22 : 14 }}>FAMILY</div>
          <div style={{ fontFamily: warmTokens.bodySerif, fontStyle: 'italic', color: warmTokens.ink, fontSize: wide ? 16 : 14, letterSpacing: 0, marginTop: 4 }}>Proto-Semitic</div>
          <div style={{ marginTop: wide ? 22 : 14 }}>FIRST ATTESTED</div>
          <div style={{ fontFamily: warmTokens.bodySerif, fontStyle: 'italic', color: warmTokens.ink, fontSize: wide ? 16 : 14, letterSpacing: 0, marginTop: 4 }}>Biblical Hebrew, c. 10 BCE</div>
        </div>
        <p style={{
          fontFamily: warmTokens.bodySerif,
          fontSize: wide ? 22 : 18,
          lineHeight: 1.65,
          color: warmTokens.ink,
          margin: 0,
          textWrap: 'pretty',
        }}>
          <span style={{ fontFamily: warmTokens.display, fontSize: wide ? 72 : 52, lineHeight: 0.85, float: 'right', marginLeft: wide ? 14 : 10, marginTop: 4, color: warmTokens.ink, fontStyle: 'italic' }}>F</span>
          {WL_CONTENT.etymology}
        </p>
      </div>
    </div>
  );
}

/* ───── visual ───── */
function WLVisual({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '0 120px' : '0 24px', marginTop: wide ? 72 : 48 }}>
      <WLSectionHead roman="III." en="IMAGE" he="מחשה" wide={wide} />
      <figure style={{ margin: 0 }}>
        <div style={{
          width: '100%',
          aspectRatio: wide ? '16 / 7' : '4 / 3',
          background: `repeating-linear-gradient(135deg, ${warmTokens.paper} 0 2px, ${warmTokens.cream} 2px 8px)`,
          border: `1px solid ${warmTokens.rule}`,
          boxShadow: `inset 0 0 0 8px ${warmTokens.cream}, inset 0 0 0 9px ${warmTokens.rule}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: warmTokens.pencil,
          fontFamily: 'ui-monospace, "SFMono-Regular", monospace',
          fontSize: 11, letterSpacing: '0.18em',
          direction: 'ltr',
        }}>
          [ PLATE — DRAWN ENGRAVING OF A SLEEPING FIGURE ]
        </div>
        <figcaption style={{
          fontFamily: warmTokens.bodySerif,
          fontStyle: 'italic',
          fontSize: wide ? 15 : 13,
          color: warmTokens.pencil,
          textAlign: 'center',
          marginTop: 10,
          direction: 'ltr',
        }}>
          PLATE I. — “A dreamer at the lamp.” After an engraving in the manner of Doré.
        </figcaption>
      </figure>
    </div>
  );
}

/* ───── take it further ───── */
function WLTiles({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '0 120px' : '0 24px', marginTop: wide ? 72 : 48 }}>
      <WLSectionHead roman="IV." en="GOING DEEPER" he="להעמיק" wide={wide} />
      <div style={{ border: `1px solid ${warmTokens.rule}`, borderBottom: 'none' }}>
        {WL_CONTENT.tiles.map((t, i) => (
          <div key={i} style={{
            display: 'grid',
            gridTemplateColumns: wide ? '80px 1fr 140px 120px' : '36px 1fr auto',
            gap: wide ? 24 : 14,
            alignItems: 'center',
            padding: wide ? '22px 24px' : '16px 14px',
            borderBottom: `1px solid ${warmTokens.rule}`,
            background: i % 2 ? warmTokens.paper : warmTokens.cream,
          }}>
            <div style={{ fontFamily: warmTokens.display, fontStyle: 'italic', fontSize: wide ? 36 : 24, color: warmTokens.oxblood, lineHeight: 1, textAlign: 'center' }}>{t.num}</div>
            <div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, flexWrap: 'wrap' }}>
                <span style={{ fontFamily: warmTokens.hebrewSerif, fontSize: wide ? 24 : 18, color: warmTokens.ink, fontWeight: 500 }}>{t.he}</span>
                <span style={{ fontFamily: warmTokens.display, fontStyle: 'italic', fontSize: wide ? 18 : 14, color: warmTokens.pencil }}>— {t.en}</span>
              </div>
              <div style={{ fontFamily: warmTokens.bodySerif, fontSize: wide ? 15 : 13, color: warmTokens.pencil, marginTop: 4, lineHeight: 1.45, textWrap: 'pretty' }}>
                {t.desc}
              </div>
            </div>
            {wide && (
              <div style={{ textAlign: 'center' }}>
                <WLTier tier={t.tier} />
              </div>
            )}
            <div style={{ textAlign: 'left', fontFamily: warmTokens.smallcaps, fontSize: wide ? 11 : 9, letterSpacing: '0.22em', color: warmTokens.ink }}>
              {!wide && <div style={{ marginBottom: 4 }}><WLTier tier={t.tier} /></div>}
              <span style={{ borderBottom: `1px solid ${warmTokens.ink}`, paddingBottom: 1 }}>OPEN →</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───── footer mark ───── */
function WLFooter({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '64px 120px 48px' : '48px 24px 32px', textAlign: 'center' }}>
      <WLOrnament size={wide ? 20 : 16} />
      <div style={{ fontFamily: warmTokens.smallcaps, fontSize: wide ? 10 : 9, letterSpacing: '0.34em', color: warmTokens.pencil, marginTop: 10 }}>
        GADIT · A DICTIONARY FOR READERS · FOLIO 1 OF 1
      </div>
    </div>
  );
}

/* ───── full pages ───── */
function DesktopWarmLibrary() {
  return (
    <div style={{ width: 1440, minHeight: 2440, background: warmTokens.cream, color: warmTokens.ink, fontFamily: warmTokens.bodySerif }}>
      <WLNav wide />
      <WLWordHead wide />
      <WLDefinitions wide />
      <WLEtymology wide />
      <WLVisual wide />
      <WLTiles wide />
      <WLFooter wide />
    </div>
  );
}
function MobileWarmLibrary() {
  return (
    <div style={{ width: 390, minHeight: 2200, background: warmTokens.cream, color: warmTokens.ink, fontFamily: warmTokens.bodySerif }}>
      <WLNav wide={false} />
      <WLWordHead wide={false} />
      <WLDefinitions wide={false} />
      <WLEtymology wide={false} />
      <WLVisual wide={false} />
      <WLTiles wide={false} />
      <WLFooter wide={false} />
    </div>
  );
}

Object.assign(window, { DesktopWarmLibrary, MobileWarmLibrary });
