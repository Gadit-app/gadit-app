/* Composes the design canvas with the 3 directions. */
const { DesignCanvas, DCSection, DCArtboard } = window;

const Brief = ({ feeling, audience, type, palette, icons, cards, hover, antiPattern, accent }) => (
  <div style={{
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 32,
    padding: '28px 32px',
    width: 1440 - 64,
    background: '#101013',
    color: '#E8E5DE',
    fontFamily: 'Inter, system-ui, sans-serif',
    fontSize: 13,
    lineHeight: 1.55,
    borderTop: `2px solid ${accent}`,
    direction: 'ltr',
    textAlign: 'left',
  }}>
    <div>
      <div style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: accent, marginBottom: 6 }}>Feeling &amp; audience</div>
      <p style={{ margin: 0, color: '#D6D2C8', fontSize: 14, lineHeight: 1.6 }}>{feeling}</p>
      <p style={{ margin: '10px 0 0', color: '#8C8779' }}><em>For:</em> {audience}</p>
    </div>
    <div>
      <div style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: accent, marginBottom: 6 }}>Design choices</div>
      <Row k="Type" v={type} />
      <Row k="Palette" v={palette} />
      <Row k="Icons" v={icons} />
      <Row k="Cards" v={cards} />
      <Row k="Hover" v={hover} />
      <div style={{ marginTop: 12, padding: '10px 12px', borderLeft: `3px solid #B23A3A`, background: '#1A1310', color: '#E8C5C0' }}>
        <strong style={{ color: '#FF9F8E' }}>Wrong for Gadit:</strong> {antiPattern}
      </div>
    </div>
  </div>
);
const Row = ({ k, v }) => (
  <div style={{ display: 'grid', gridTemplateColumns: '88px 1fr', gap: 12, padding: '4px 0', borderBottom: '1px solid #22222A' }}>
    <div style={{ color: '#76726A' }}>{k}</div>
    <div style={{ color: '#D6D2C8' }}>{v}</div>
  </div>
);

function App() {
  return (
    <DesignCanvas>
      <DCSection id="warm" title="01 · Warm Library" subtitle="An object you'd keep on a shelf.">
        <DCArtboard id="warm-desktop" label="Desktop · 1440" width={1440} height={2440}>
          <window.DesktopWarmLibrary />
        </DCArtboard>
        <DCArtboard id="warm-mobile" label="Mobile · 390" width={390} height={2200}>
          <window.MobileWarmLibrary />
        </DCArtboard>
        <DCArtboard id="warm-brief" label="Notes" width={1440 - 64} height={300}>
          <Brief
            accent="#8B2A1A"
            feeling="A beautifully printed reference book on warm paper — classical, slow, considered. Reads like a thing you settle into with coffee. Hebrew and Latin both feel native because the type is doing serious work."
            audience="Adults who already love reading. Translators, students of Hebrew literature, religious scholars, writers."
            type='EB Garamond (body) · Cormorant Garamond (display) · Cormorant SC (section labels) · Frank Ruhl Libre (Hebrew serif)'
            palette='Cream #F2EAD6 · Ink #1F1A12 · Oxblood #8B2A1A · Pencil #6B6358'
            icons='Engraving-style monochrome glyphs, hairline strokes — ornaments not symbols.'
            cards='No cards. The page is a printed spread: hairline rules, drop-caps, generous margins, page-number-style metadata.'
            hover='Ink darkens. Underline appears as if drawn with a nib. No transforms.'
            antiPattern='A "modern editorial" hybrid with a coloured pull-quote, an off-white card, and a contemporary sans for metadata. It loses the artifact feeling and becomes a Medium post."'
          />
        </DCArtboard>
      </DCSection>

      <DCSection id="tech" title="02 · Crisp Tech" subtitle="A productivity tool for words.">
        <DCArtboard id="tech-desktop" label="Desktop · 1440" width={1440} height={2280}>
          <window.DesktopCrispTech />
        </DCArtboard>
        <DCArtboard id="tech-mobile" label="Mobile · 390" width={390} height={2100}>
          <window.MobileCrispTech />
        </DCArtboard>
        <DCArtboard id="tech-brief" label="Notes" width={1440 - 64} height={300}>
          <Brief
            accent="#0EA5A5"
            feeling="A precision instrument. Lots of whitespace, sharp typography, monospaced metadata where it earns its place. Feels fast. The same kind of confidence as a well-built developer tool — but for language."
            audience="Bilingual professionals, software people who happen to love words, language-learners who use Anki and read changelogs for fun."
            type='Inter (entire UI, 400/500/600/700) · JetBrains Mono (IPA, metadata, codes) · Heebo (Hebrew sans)'
            palette='Paper #FAFAFA · Graphite #0B0F19 · Mist #E6E8EC · Teal #0EA5A5'
            icons='1.5px stroke geometric line icons, single colour. Optical alignment matters more than decoration.'
            cards='Flat white cards on paper-grey background, 1px border, one teal left-edge for active states. Shadows almost imperceptible.'
            hover='Background lifts to #F4F5F7, border darkens 1 step, focus ring is 2px teal at 30% opacity. No bounce.'
            antiPattern='Adding glassmorphism, a hero gradient, or a "dashboard"-style sidebar with a count of saved words. That turns a focused reading surface into a CRM."'
          />
        </DCArtboard>
      </DCSection>

      <DCSection id="play" title="03 · Playful Bookshop" subtitle="Apple Books meets the kids' aisle.">
        <DCArtboard id="play-desktop" label="Desktop · 1440" width={1440} height={2520}>
          <window.DesktopPlayfulBookshop />
        </DCArtboard>
        <DCArtboard id="play-mobile" label="Mobile · 390" width={390} height={2280}>
          <window.MobilePlayfulBookshop />
        </DCArtboard>
        <DCArtboard id="play-brief" label="Notes" width={1440 - 64} height={300}>
          <Brief
            accent="#FF6B47"
            feeling="A children's bookshop that adults also love. Saturated multi-colour, rounded everything, illustrated badges with character. Each section is a different 'room' with its own colour. It rewards curiosity and feels like play, not like school."
            audience="Families (parents + kids using it together), teachers, hobbyist learners, anyone who buys hardcover picture books for themselves."
            type='Bricolage Grotesque (display, 700/800) · Nunito (body, 600/700) · Caveat (handwritten asides) · Rubik 900 (Hebrew display)'
            palette='Butter #FFF4D6 · Plum #2E1A47 · Tomato #FF6B47 · Mint #34D399 · Lilac #A78BFA'
            icons='Illustrated character-badges with saturated fills and a hand-drawn outline. Symbols become little creatures.'
            cards='24–32px rounding, 6px hard offset shadow in plum, occasional 1–2° rotation. Each section uses a different room colour.'
            hover='Bouncy spring scale to 1.03 with a 4px tilt; shadow grows; small wobble on the badge. Delightful, not distracting.'
            antiPattern='Layering rainbow gradients and animated emoji over everything. Saturation without composition becomes Comic Sans energy — the playfulness has to be carried by shape and rhythm, not noise."'
          />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
