/* Direction 2 — CRISP TECH
   Linear/Notion feel. Inter + JetBrains Mono + Heebo. Teal accent. */

const techTokens = {
  paper:   '#FAFAFA',
  card:    '#FFFFFF',
  border:  '#E6E8EC',
  border2: '#D4D7DD',
  mist:    '#F4F5F7',
  ink:     '#0B0F19',
  ink2:    '#3A3F4B',
  ink3:    '#5C6270',
  ink4:    '#8B91A0',
  teal:    '#0EA5A5',
  tealSoft:'#E0F6F4',
  tealEdge:'#0B8A8A',
  sans:    'Inter, "Heebo", system-ui, sans-serif',
  he:      '"Heebo", Inter, system-ui, sans-serif',
  mono:    '"JetBrains Mono", ui-monospace, monospace',
};

const CT_CONTENT = {
  word: 'חלום',
  translit: 'ḥalom',
  ipa: '/xaˈlom/',
  meta: [
    { k: 'pos',    v: 'noun' },
    { k: 'gender', v: 'm.' },
    { k: 'plural', v: 'חלומות · ḥalomot' },
    { k: 'root',   v: 'ח · ל · מ' },
  ],
  definitions: [
    {
      label: 'sense_01',
      kind:  'literal',
      gloss: 'A sequence of images, ideas, and sensations occurring involuntarily in the mind during sleep; the experience of dreaming.',
      hebrew: 'ראיתי חלום מוזר אמש.',
      english: 'I had a strange dream last night.',
    },
    {
      label: 'sense_02',
      kind:  'figurative',
      gloss: 'A cherished aspiration; an ideal one hopes to attain — typically with a possessive.',
      hebrew: 'החלום של אבא היה לבנות בית קטן ליד הים.',
      english: 'Father’s dream was to build a small house by the sea.',
    },
  ],
  etymology: 'From the Proto-Semitic root ḥ-l-m — “to dream” and, in some cognates, “to be whole, sound”. Cognate with Akkadian ḫalāmu, Arabic ḥulm (حُلم), and Ge‘ez ḥalama. First attested in Biblical Hebrew; carries prophetic weight in the Joseph cycle of Genesis 37.',
  cognates: [
    { lang: 'Akkadian', form: 'ḫalāmu' },
    { lang: 'Arabic',   form: 'ḥulm · حُلم' },
    { lang: 'Ge‘ez',    form: 'ḥalama' },
    { lang: 'Aramaic',  form: 'ḥelmā' },
  ],
  tiles: [
    { num: '01', he: 'הסבר לילדים',  en: 'Kids’ explanation',  desc: 'Simplified for ages 6–10.',          tier: 'CLEAR', glyph: 'kids' },
    { num: '02', he: 'חיבור משפט',    en: 'Compose a sentence', desc: 'Live feedback on register.',         tier: 'CLEAR', glyph: 'edit' },
    { num: '03', he: 'השוואת מילים',  en: 'Compare words',      desc: 'חלום vs. הזיה vs. משאלה.',           tier: 'DEEP',  glyph: 'compare' },
    { num: '04', he: 'מבחן עצמי',     en: 'Quiz yourself',      desc: 'Eight adaptive questions.',          tier: 'DEEP',  glyph: 'quiz' },
  ],
};

/* ───── 1.5px line icons ───── */
const CTIcon = ({ name, size = 18, color = 'currentColor', stroke = 1.5 }) => {
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'search':    return <svg {...p}><circle cx="11" cy="11" r="6.5" /><path d="m20 20-4-4" /></svg>;
    case 'bookmark':  return <svg {...p}><path d="M6 3h12v18l-6-4-6 4z" /></svg>;
    case 'share':     return <svg {...p}><path d="M5 13v6a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-6" /><path d="M12 3v13" /><path d="m8 7 4-4 4 4" /></svg>;
    case 'chevdown':  return <svg {...p}><path d="m6 9 6 6 6-6" /></svg>;
    case 'arrowne':   return <svg {...p}><path d="M7 17 17 7" /><path d="M9 7h8v8" /></svg>;
    case 'lock':      return <svg {...p}><rect x="5" y="11" width="14" height="9" rx="1.5" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></svg>;
    case 'kids':      return <svg {...p}><circle cx="12" cy="9" r="3.5" /><path d="M5 21c0-3.5 3-6 7-6s7 2.5 7 6" /><circle cx="10" cy="9" r="0.4" fill={color} stroke="none" /><circle cx="14" cy="9" r="0.4" fill={color} stroke="none" /></svg>;
    case 'edit':      return <svg {...p}><path d="M4 20h4l10-10-4-4L4 16z" /><path d="M14 6l4 4" /></svg>;
    case 'compare':   return <svg {...p}><rect x="3" y="5" width="8" height="14" rx="1" /><rect x="13" y="5" width="8" height="14" rx="1" /><path d="M7 9v6M17 9v6" /></svg>;
    case 'quiz':      return <svg {...p}><circle cx="12" cy="12" r="9" /><path d="M9.5 9.5a2.5 2.5 0 1 1 4 2c-1 .8-1.5 1.4-1.5 2.5" /><circle cx="12" cy="17.5" r="0.5" fill={color} stroke="none" /></svg>;
    case 'crosshair': return <svg {...p}><circle cx="12" cy="12" r="9" /><path d="M12 3v6M12 15v6M3 12h6M15 12h6" /></svg>;
    case 'globe':     return <svg {...p}><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18" /></svg>;
    case 'volume':    return <svg {...p}><path d="M4 10v4h3l4 3V7L7 10z" /><path d="M15 9a4 4 0 0 1 0 6" /><path d="M18 6a8 8 0 0 1 0 12" /></svg>;
    default:          return null;
  }
};

/* ───── nav ───── */
function CTNav({ wide }) {
  return (
    <div style={{
      direction: 'rtl',
      borderBottom: `1px solid ${techTokens.border}`,
      background: techTokens.card,
      padding: wide ? '0 56px' : '0 16px',
      height: wide ? 60 : 52,
      display: 'flex',
      alignItems: 'center',
      gap: wide ? 28 : 12,
      fontFamily: techTokens.sans,
      color: techTokens.ink,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, direction: 'ltr' }}>
        <div style={{ width: 22, height: 22, borderRadius: 6, background: techTokens.ink, position: 'relative' }}>
          <div style={{ position: 'absolute', inset: 4, borderRadius: 3, background: techTokens.teal }} />
          <div style={{ position: 'absolute', inset: 8, borderRadius: 1, background: techTokens.card }} />
        </div>
        <span style={{ fontWeight: 600, fontSize: 16, letterSpacing: '-0.01em' }}>Gadit</span>
      </div>

      {wide && (
        <>
          <div style={{
            flex: 1,
            maxWidth: 360,
            height: 36,
            border: `1px solid ${techTokens.border}`,
            borderRadius: 8,
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            padding: '0 12px',
            background: techTokens.mist,
            color: techTokens.ink3,
            fontSize: 13,
          }}>
            <CTIcon name="search" size={15} />
            <span>חיפוש מילה · Search</span>
            <span style={{ marginInlineStart: 'auto', fontFamily: techTokens.mono, fontSize: 11, padding: '2px 6px', border: `1px solid ${techTokens.border2}`, borderRadius: 4, background: techTokens.card }}>⌘K</span>
          </div>
          <div style={{ flex: 1 }} />
          <a style={{ fontSize: 13, color: techTokens.ink2, textDecoration: 'none' }}>תמחור</a>
          <span style={{ color: techTokens.border2 }}>·</span>
          <a style={{ fontSize: 13, color: techTokens.ink2, textDecoration: 'none' }}>Pricing</a>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px', border: `1px solid ${techTokens.border}`, borderRadius: 6, fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink2 }}>
            <CTIcon name="globe" size={13} color={techTokens.ink3} />
            HE/EN
            <CTIcon name="chevdown" size={12} color={techTokens.ink3} />
          </div>
          <button style={{ background: techTokens.ink, color: techTokens.card, border: 'none', padding: '7px 14px', borderRadius: 6, fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>Sign in</button>
        </>
      )}
      {!wide && (
        <div style={{ marginInlineStart: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '6px 8px', border: `1px solid ${techTokens.border}`, borderRadius: 6, fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink2 }}>HE/EN</div>
          <button style={{ background: techTokens.ink, color: techTokens.card, border: 'none', padding: '6px 12px', borderRadius: 6, fontSize: 12, fontWeight: 500 }}>Sign in</button>
        </div>
      )}
    </div>
  );
}

/* ───── breadcrumb ───── */
function CTBreadcrumb({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '24px 56px 0' : '14px 16px 0', fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink4 }}>
      <span>dictionary</span>
      <span style={{ margin: '0 8px' }}>/</span>
      <span>he</span>
      <span style={{ margin: '0 8px' }}>/</span>
      <span style={{ color: techTokens.ink2 }}>ḥalom</span>
    </div>
  );
}

/* ───── hero ───── */
function CTHero({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '20px 56px 36px' : '12px 16px 24px', fontFamily: techTokens.sans, color: techTokens.ink }}>
      <div style={{ display: 'flex', alignItems: wide ? 'flex-end' : 'flex-start', justifyContent: 'space-between', gap: wide ? 32 : 12, flexDirection: wide ? 'row' : 'column' }}>
        <div>
          <div style={{
            fontFamily: techTokens.he,
            fontWeight: 700,
            fontSize: wide ? 120 : 64,
            lineHeight: 1,
            letterSpacing: '-0.02em',
          }}>
            {CT_CONTENT.word}
            <span style={{
              display: 'inline-block',
              width: wide ? 12 : 7, height: wide ? 12 : 7,
              borderRadius: 99,
              background: techTokens.teal,
              marginInlineStart: wide ? 18 : 10,
              transform: `translateY(${wide ? -28 : -18}px)`,
            }} />
          </div>
          <div style={{ marginTop: wide ? 16 : 10, display: 'flex', gap: wide ? 16 : 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: wide ? 22 : 18, color: techTokens.ink2, letterSpacing: '-0.01em' }}>{CT_CONTENT.translit}</span>
            <span style={{ fontFamily: techTokens.mono, fontSize: wide ? 14 : 12, color: techTokens.ink3, padding: '3px 8px', border: `1px solid ${techTokens.border}`, borderRadius: 4, background: techTokens.card }}>{CT_CONTENT.ipa}</span>
            <button style={{ background: techTokens.card, border: `1px solid ${techTokens.border}`, borderRadius: 6, padding: '6px 8px', display: 'inline-flex', alignItems: 'center', gap: 6, color: techTokens.ink2, fontFamily: techTokens.sans, fontSize: 12, cursor: 'pointer' }}>
              <CTIcon name="volume" size={14} color={techTokens.teal} />
              listen
            </button>
          </div>
          <div style={{ marginTop: wide ? 14 : 10, display: 'flex', gap: wide ? 18 : 10, flexWrap: 'wrap' }}>
            {CT_CONTENT.meta.map((m) => (
              <span key={m.k} style={{ fontFamily: techTokens.mono, fontSize: wide ? 12 : 11, color: techTokens.ink3 }}>
                <span style={{ color: techTokens.ink4 }}>{m.k}:</span>
                <span style={{ marginInlineStart: 6, color: techTokens.ink2 }}>{m.v}</span>
              </span>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: techTokens.card, border: `1px solid ${techTokens.border}`, borderRadius: 8,
            padding: '8px 14px', fontFamily: techTokens.sans, fontSize: 13, fontWeight: 500, color: techTokens.ink, cursor: 'pointer',
          }}>
            <CTIcon name="bookmark" size={15} color={techTokens.ink2} />
            Save
            <span style={{ fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink4, marginInlineStart: 4, padding: '1px 5px', border: `1px solid ${techTokens.border}`, borderRadius: 3, background: techTokens.mist }}>S</span>
          </button>
          <button style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: techTokens.card, border: `1px solid ${techTokens.border}`, borderRadius: 8,
            padding: '8px 14px', fontFamily: techTokens.sans, fontSize: 13, fontWeight: 500, color: techTokens.ink, cursor: 'pointer',
          }}>
            <CTIcon name="share" size={15} color={techTokens.ink2} />
            Share
          </button>
        </div>
      </div>
    </div>
  );
}

/* ───── section label ───── */
function CTSecLabel({ num, en, he }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
      <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.teal }}>{num}</span>
      <span style={{ fontFamily: techTokens.sans, fontWeight: 600, fontSize: 14, color: techTokens.ink, letterSpacing: '-0.01em' }}>{en}</span>
      <span style={{ fontFamily: techTokens.he, fontWeight: 500, fontSize: 14, color: techTokens.ink3 }}>· {he}</span>
    </div>
  );
}

/* ───── definitions ───── */
function CTDefinitions({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '12px 56px 0' : '0 16px', fontFamily: techTokens.sans }}>
      <CTSecLabel num="01" en="Definitions" he="הגדרות" />
      <div style={{ marginTop: wide ? 18 : 14, display: 'grid', gridTemplateColumns: wide ? '1fr 1fr' : '1fr', gap: wide ? 16 : 12 }}>
        {CT_CONTENT.definitions.map((d, i) => (
          <div key={i} style={{
            background: techTokens.card,
            border: `1px solid ${techTokens.border}`,
            borderInlineStartWidth: 3,
            borderInlineStartColor: techTokens.teal,
            borderRadius: 10,
            padding: wide ? '20px 22px' : '16px 16px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink4 }}>{d.label}</span>
              <span style={{
                fontFamily: techTokens.mono,
                fontSize: 10,
                padding: '2px 8px',
                borderRadius: 99,
                background: d.kind === 'literal' ? techTokens.tealSoft : '#FFF1E6',
                color: d.kind === 'literal' ? techTokens.tealEdge : '#A0531C',
                letterSpacing: '0.04em',
              }}>{d.kind}</span>
            </div>
            <p style={{ margin: 0, fontSize: wide ? 16 : 15, lineHeight: 1.55, color: techTokens.ink, textWrap: 'pretty' }}>
              {d.gloss}
            </p>
            <div style={{ marginTop: 14, padding: 12, background: techTokens.mist, borderRadius: 6, borderInlineStart: `2px solid ${techTokens.border2}` }}>
              <div style={{ fontFamily: techTokens.he, fontWeight: 500, fontSize: wide ? 17 : 15, color: techTokens.ink, lineHeight: 1.5 }}>{d.hebrew}</div>
              <div style={{ fontSize: wide ? 13 : 12, color: techTokens.ink3, marginTop: 4, direction: 'ltr', textAlign: 'right' }}>{d.english}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ───── etymology ───── */
function CTEtymology({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '40px 56px 0' : '28px 16px 0', fontFamily: techTokens.sans }}>
      <CTSecLabel num="02" en="Word origin" he="מקור המילה" />
      <div style={{
        marginTop: wide ? 18 : 14,
        background: techTokens.card,
        border: `1px solid ${techTokens.border}`,
        borderRadius: 10,
        overflow: 'hidden',
        display: 'grid',
        gridTemplateColumns: wide ? '320px 1px 1fr' : '1fr',
        gridTemplateRows: wide ? 'auto' : 'auto 1px auto',
      }}>
        <div style={{ padding: wide ? '20px 22px' : '16px', background: techTokens.mist }}>
          <div style={{ fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink4, letterSpacing: '0.06em', textTransform: 'uppercase' }}>root</div>
          <div style={{ fontFamily: techTokens.he, fontWeight: 700, fontSize: wide ? 36 : 30, color: techTokens.ink, marginTop: 6, letterSpacing: '0.15em' }}>ח · ל · מ</div>
          <div style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink3, marginTop: 2 }}>ḥ-l-m · "to dream / to be sound"</div>

          <div style={{ height: 1, background: techTokens.border, margin: '16px 0' }} />

          <div style={{ fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink4, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 8 }}>cognates</div>
          <div style={{ display: 'grid', gap: 6 }}>
            {CT_CONTENT.cognates.map((c) => (
              <div key={c.lang} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: techTokens.mono, fontSize: 12 }}>
                <span style={{ color: techTokens.ink3 }}>{c.lang}</span>
                <span style={{ color: techTokens.ink, direction: 'ltr' }}>{c.form}</span>
              </div>
            ))}
          </div>
        </div>
        {wide && <div style={{ background: techTokens.border }} />}
        {!wide && <div style={{ background: techTokens.border, height: 1 }} />}
        <div style={{ padding: wide ? '20px 22px' : '16px' }}>
          <div style={{ fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink4, letterSpacing: '0.06em', textTransform: 'uppercase' }}>history</div>
          <p style={{ margin: '8px 0 0', fontSize: wide ? 16 : 14, lineHeight: 1.6, color: techTokens.ink, textWrap: 'pretty' }}>
            {CT_CONTENT.etymology}
          </p>
          <div style={{ marginTop: 16, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink3, padding: '4px 10px', borderRadius: 99, border: `1px solid ${techTokens.border}`, background: techTokens.mist }}>Proto-Semitic</span>
            <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink3, padding: '4px 10px', borderRadius: 99, border: `1px solid ${techTokens.border}`, background: techTokens.mist }}>Biblical Hebrew</span>
            <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink3, padding: '4px 10px', borderRadius: 99, border: `1px solid ${techTokens.border}`, background: techTokens.mist }}>Genesis 37</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───── visual ───── */
function CTVisual({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '40px 56px 0' : '28px 16px 0', fontFamily: techTokens.sans }}>
      <CTSecLabel num="03" en="Visual" he="מחשה" />
      <div style={{
        marginTop: wide ? 18 : 14,
        background: techTokens.card,
        border: `1px solid ${techTokens.border}`,
        borderRadius: 10,
        height: wide ? 360 : 220,
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(${techTokens.border} 1px, transparent 1px), linear-gradient(90deg, ${techTokens.border} 1px, transparent 1px)`,
          backgroundSize: '32px 32px',
          opacity: 0.55,
        }} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 14 }}>
          <CTIcon name="crosshair" size={28} color={techTokens.ink4} stroke={1.25} />
          <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink4, letterSpacing: '0.08em', direction: 'ltr' }}>
            VISUAL · 1600×900 · generated_at_render
          </span>
        </div>
        <div style={{ position: 'absolute', top: 12, insetInlineStart: 12, fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink4, padding: '3px 8px', borderRadius: 4, background: techTokens.mist, border: `1px solid ${techTokens.border}` }}>visual.png</div>
      </div>
    </section>
  );
}

/* ───── tiles ───── */
function CTTier({ tier }) {
  const isDeep = tier === 'DEEP';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontFamily: techTokens.mono, fontSize: 10, fontWeight: 500,
      padding: '3px 8px',
      borderRadius: 4,
      background: isDeep ? '#FFF1E6' : techTokens.tealSoft,
      color: isDeep ? '#A0531C' : techTokens.tealEdge,
      border: `1px solid ${isDeep ? '#F7D9C2' : '#C5E8E5'}`,
    }}>
      {isDeep && <CTIcon name="lock" size={10} stroke={1.6} />}
      {tier}
    </span>
  );
}

function CTTiles({ wide }) {
  return (
    <section style={{ direction: 'rtl', padding: wide ? '40px 56px 0' : '28px 16px 0', fontFamily: techTokens.sans }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <CTSecLabel num="04" en="Take it further" he="להעמיק" />
        <span style={{ fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink4 }}>4 actions</span>
      </div>
      <div style={{
        marginTop: wide ? 18 : 14,
        display: 'grid',
        gridTemplateColumns: wide ? 'repeat(4, 1fr)' : '1fr 1fr',
        gap: wide ? 14 : 10,
      }}>
        {CT_CONTENT.tiles.map((t, i) => (
          <div key={i} style={{
            background: techTokens.card,
            border: `1px solid ${techTokens.border}`,
            borderRadius: 10,
            padding: wide ? '18px 18px 16px' : '14px',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column',
            gap: 12,
            minHeight: wide ? 180 : 160,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: techTokens.tealSoft, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <CTIcon name={t.glyph} size={18} color={techTokens.tealEdge} />
              </div>
              <CTTier tier={t.tier} />
            </div>
            <div>
              <div style={{ fontFamily: techTokens.he, fontWeight: 700, fontSize: wide ? 17 : 15, color: techTokens.ink }}>{t.he}</div>
              <div style={{ fontFamily: techTokens.sans, fontWeight: 500, fontSize: wide ? 13 : 12, color: techTokens.ink3, marginTop: 2 }}>{t.en}</div>
              <div style={{ fontSize: wide ? 13 : 12, color: techTokens.ink3, marginTop: 8, lineHeight: 1.45 }}>{t.desc}</div>
            </div>
            <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: techTokens.mono, fontSize: 10, color: techTokens.ink4 }}>{t.num}</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, color: techTokens.teal, fontWeight: 500 }}>
                Open
                <CTIcon name="arrowne" size={12} color={techTokens.teal} />
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ───── footer ───── */
function CTFooter({ wide }) {
  return (
    <div style={{ direction: 'rtl', padding: wide ? '40px 56px 32px' : '24px 16px', fontFamily: techTokens.mono, fontSize: 11, color: techTokens.ink4, borderTop: `1px solid ${techTokens.border}`, marginTop: wide ? 40 : 28, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
      <span>gadit.app/he/ḥalom</span>
      <span>updated 2026-05-27 · v2.4.0</span>
    </div>
  );
}

/* ───── full pages ───── */
function DesktopCrispTech() {
  return (
    <div style={{ width: 1440, minHeight: 2280, background: techTokens.paper, color: techTokens.ink, fontFamily: techTokens.sans }}>
      <CTNav wide />
      <CTBreadcrumb wide />
      <CTHero wide />
      <CTDefinitions wide />
      <CTEtymology wide />
      <CTVisual wide />
      <CTTiles wide />
      <CTFooter wide />
    </div>
  );
}
function MobileCrispTech() {
  return (
    <div style={{ width: 390, minHeight: 2100, background: techTokens.paper, color: techTokens.ink, fontFamily: techTokens.sans }}>
      <CTNav wide={false} />
      <CTBreadcrumb wide={false} />
      <CTHero wide={false} />
      <CTDefinitions wide={false} />
      <CTEtymology wide={false} />
      <CTVisual wide={false} />
      <CTTiles wide={false} />
      <CTFooter wide={false} />
    </div>
  );
}

Object.assign(window, { DesktopCrispTech, MobileCrispTech });
